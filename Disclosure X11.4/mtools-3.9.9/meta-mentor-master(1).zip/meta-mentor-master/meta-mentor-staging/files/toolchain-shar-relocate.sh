$SUDO_EXEC $target_sdk_dir/relocate_sdk.sh
