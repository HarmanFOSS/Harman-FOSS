OpenEmbedded/Yocto layers for Mentor Embedded Linux Flex OS
===================================================

This repository holds the layers needed by our Yocto builds of Mentor Embedded
Linux. At this time there are three such layers:

- meta-mel: The Mentor Embedded Linux Flex OS distribution layer
- meta-mel-support: Support files for MEL
- meta-mentor-staging: Our staging area for bits which belong upstream

See the individual layer readmes for additional detail and contribution
information.
